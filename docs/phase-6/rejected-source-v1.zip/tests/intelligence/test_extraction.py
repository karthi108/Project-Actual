"""Deterministic extraction/service tests; no local model is required."""

import asyncio
import json
from typing import Any

import pytest
from pydantic import ValidationError

from actual.capabilities.job_requirements import (
    JOB_REQUIREMENTS,
    ExtractionInput,
    ExtractionOutput,
)
from actual.career.jobs import Requirement
from actual.career.snapshot import CareerSnapshot
from actual.careerlab.generator import generate_inputs
from actual.careerlab_bridge import ImportContext, map_observable
from actual.core.primitives import ActorId, WorkspaceId, canonical_bytes
from actual.job_intelligence.errors import IntelligenceFailure
from actual.job_intelligence.service import IntelligenceResult, JobIntelligence
from actual.models.contracts import (
    GenerationSettings,
    PreparedInference,
    ProviderIdentity,
    ProviderReply,
)
from actual.models.errors import FailureCode, ModelFailure
from actual.models.gateway import ModelGateway, canonical_json


def world(case: int = 0) -> CareerSnapshot:
    return map_observable(
        generate_inputs()[case],
        ImportContext(
            workspace_id=WorkspaceId("workspace_" + "1" * 32),
            actor_id=ActorId("actor_" + "2" * 32),
        ),
    )


def unit(quote: str, term: str, priority: str = "essential") -> dict[str, str]:
    return {"quote": quote, "term": term, "priority": priority}


def output(*units: dict[str, str]) -> dict[str, object]:
    return {
        "schema_version": "actual-job-requirements-output-v1",
        "requirements": list(units),
    }


class FakeExtractionProvider:
    def __init__(self, content: str | None = None, failure: ModelFailure | None = None) -> None:
        self.identity = ProviderIdentity(
            provider="fake", model="synthetic-model", endpoint="http://127.0.0.1:11434"
        )
        self.settings = GenerationSettings(max_output_tokens=512)
        self.content = content or canonical_json(
            output(unit("Python at working level is essential.", "Python"))
        )
        self.failure = failure
        self.requests: list[PreparedInference] = []

    async def infer(self, request: PreparedInference) -> ProviderReply:
        self.requests.append(request)
        if self.failure is not None:
            raise self.failure
        return ProviderReply(
            content=self.content,
            model=self.identity.model,
            model_digest=None,
            server_version=None,
        )


def service(provider: FakeExtractionProvider) -> JobIntelligence:
    return JobIntelligence(ModelGateway(provider, capabilities=(JOB_REQUIREMENTS,)))


def assess(
    provider: FakeExtractionProvider, source: CareerSnapshot | None = None
) -> IntelligenceResult:
    source = source or world()
    return asyncio.run(service(provider).assess(source.jobs[0], source.profile))


def test_simple_extraction_is_source_pinned_and_evidence_backed() -> None:
    source = world()
    before = canonical_bytes(source)
    provider = FakeExtractionProvider()
    result = assess(provider, source)
    assert type(result) is IntelligenceResult
    assert result.metadata.capability == "job_requirement_extraction:v1"
    assert result.metadata.schema_version == "actual-job-requirements-output-v1"
    assert result.metadata.settings.max_output_tokens == 512
    assert result.metadata.proposal_only is True
    row = result.assessment.rows[0]
    assert type(row.requirement) is Requirement
    assert row.requirement.assertion.subject == "python"
    assert row.requirement.assertion.value == 2
    assert row.requirement.origin == "ai_proposal" and row.requirement.review is None
    assert row.status == "supported" and row.claim_refs and row.evidence_refs
    assert row.requirement.job_digest == source.jobs[0].content_digest
    assert (
        row.requirement.source_quote
        == source.jobs[0].text[row.requirement.source_start : row.requirement.source_end]
    )
    assert result.assessment.profile_digest == source.profile.content_digest
    assert canonical_bytes(source) == before
    assert source.jobs[0].text not in repr(result)
    assert len(provider.requests) == 1


def test_multiple_requirements_preserve_importance_numeric_scope_and_source_order() -> None:
    provider = FakeExtractionProvider(
        canonical_json(
            output(
                unit("Python at working level is essential.", "Python"),
                unit("French B2 is essential.", "French"),
                unit("Five years of backend experience are essential.", "experience"),
                unit(
                    "Local LLM integration at working level is preferred.",
                    "Local LLM integration",
                    "preferred",
                ),
            )
        )
    )
    result = assess(provider)
    rows = result.assessment.rows
    assert [row.status for row in rows] == ["supported", "unknown", "gap", "supported"]
    assert [row.requirement.priority for row in rows] == [
        "essential",
        "essential",
        "essential",
        "preferred",
    ]
    assert [row.requirement.assertion.value for row in rows] == [2, 4, 60, 2]
    assert rows[1].declared_shortfall is True
    assert rows[2].observed_value == 12
    assert result.assessment.counts.supported == 2
    assert result.assessment.counts.unknown == 1
    assert result.assessment.counts.gap == 1


def test_empty_extraction_is_explicit_empty_matrix_not_a_perfect_fit() -> None:
    provider = FakeExtractionProvider(canonical_json(output()))
    result = assess(provider)
    assert result.assessment.rows == ()
    assert result.assessment.counts.supported == 0
    assert not hasattr(result.assessment, "score")
    assert not hasattr(result.assessment, "recommendation")


def test_ambiguous_requirement_retains_uncertainty() -> None:
    source = world()
    job = source.jobs[0].model_copy(update={"text": "SYNTHETIC POSTING. French fluency welcomed."})
    provider = FakeExtractionProvider(
        canonical_json(output(unit("French fluency welcomed.", "French", "ambiguous")))
    )
    result = asyncio.run(service(provider).assess(job, source.profile))
    row = result.assessment.rows[0]
    assert row.requirement.priority == "ambiguous"
    assert row.status == "unknown"
    assert not row.evidence_refs
    assert not hasattr(row.requirement, "assertion")


@pytest.mark.parametrize(
    "content",
    [
        "not JSON",
        "",
        "{}",
        '{"schema_version":"actual-job-requirements-output-v1"}',
        '{"schema_version":"actual-job-requirements-output-v1","requirements":[',
        canonical_json({**output(), "evidence": []}),
        canonical_json(output({"quote": "Python", "term": "Python", "priority": "optional"})),
        canonical_json(output({"quote": 1, "term": "Python", "priority": "essential"})),
        canonical_json(output({"quote": "Python", "term": "Python"})),
        canonical_json(output(*[unit("Python", "Python")] * 9)),
    ],
)
def test_malformed_output_fails_closed_once(content: str) -> None:
    provider = FakeExtractionProvider(content)
    provider.content = content  # Empty content is deliberately malformed, not a default.
    with pytest.raises(ModelFailure) as captured:
        assess(provider)
    assert captured.value.code == FailureCode.INVALID_OUTPUT
    assert str(captured.value) == "invalid_output"
    assert len(provider.requests) == 1


@pytest.mark.parametrize(
    "proposal",
    [
        unit("Kubernetes is essential.", "Kubernetes"),
        unit("Python at working level is essential.", "Kubernetes"),
        unit("Python at working level is essential.", "Python", "preferred"),
    ],
)
def test_structurally_valid_source_or_priority_fabrication_is_rejected(
    proposal: dict[str, str],
) -> None:
    with pytest.raises(IntelligenceFailure):
        assess(FakeExtractionProvider(canonical_json(output(proposal))))


def test_duplicate_requirement_cannot_add_fit_weight() -> None:
    repeated = unit("Python at working level is essential.", "Python")
    with pytest.raises(IntelligenceFailure) as captured:
        assess(FakeExtractionProvider(canonical_json(output(repeated, repeated))))
    assert captured.value.code.value == "duplicate_requirement"


def test_repeated_source_quote_is_not_silently_bound_to_its_first_occurrence() -> None:
    source = world()
    quote = "Python at working level is essential."
    job = source.jobs[0].model_copy(update={"text": f"SYNTHETIC POSTING. {quote} {quote}"})
    provider = FakeExtractionProvider(canonical_json(output(unit(quote, "Python"))))
    with pytest.raises(IntelligenceFailure) as captured:
        asyncio.run(service(provider).assess(job, source.profile))
    assert captured.value.code.value == "invalid_requirement"
    assert len(provider.requests) == 1


def test_source_spans_count_characters_while_input_bounds_count_utf8_bytes() -> None:
    source = world()
    quote = "Python at working level is essential."
    prefix = "SYNTHETIC POSTING. équipe café. "
    job = source.jobs[0].model_copy(update={"text": prefix + quote})
    provider = FakeExtractionProvider(canonical_json(output(unit(quote, "Python"))))
    result = asyncio.run(service(provider).assess(job, source.profile))
    requirement = result.assessment.rows[0].requirement
    assert requirement.source_start == len(prefix)
    assert requirement.source_start != len(prefix.encode("utf-8"))
    assert job.text[requirement.source_start : requirement.source_end] == quote


def test_model_failures_remain_explicit_and_cause_no_source_changes() -> None:
    source = world()
    before = canonical_bytes(source)
    provider = FakeExtractionProvider(failure=ModelFailure(FailureCode.TIMEOUT))
    with pytest.raises(ModelFailure) as captured:
        assess(provider, source)
    assert captured.value.code == FailureCode.TIMEOUT
    assert len(provider.requests) == 1
    assert canonical_bytes(source) == before


@pytest.mark.parametrize("synthetic", [False, 1, "true", None])
def test_inference_input_requires_exact_synthetic_marker(synthetic: object) -> None:
    with pytest.raises(ValidationError):
        ExtractionInput.model_validate({"synthetic": synthetic, "job_text": "Python required."})


def test_input_boundary_counts_utf8_and_never_truncates() -> None:
    assert ExtractionInput(synthetic=True, job_text="x" * 1024).job_text == "x" * 1024
    assert ExtractionInput(synthetic=True, job_text="é" * 512).job_text == "é" * 512
    assert "synthetic posting" not in repr(
        ExtractionInput(synthetic=True, job_text="synthetic posting")
    )
    for text in ("x" * 1025, "é" * 513, "  ", "\ud800"):
        with pytest.raises((ValidationError, UnicodeError)):
            ExtractionInput(synthetic=True, job_text=text)
    source = world()
    provider = FakeExtractionProvider()
    long_job = source.jobs[0].model_copy(update={"text": "x" * 1025})
    with pytest.raises(IntelligenceFailure):
        asyncio.run(service(provider).assess(long_job, source.profile))
    assert provider.requests == []


def test_contract_versions_types_and_unknown_fields_are_closed() -> None:
    payload: dict[str, Any] = output(unit("Python required.", "Python"))
    parsed = ExtractionOutput.model_validate_json(json.dumps(payload))
    assert parsed.requirements[0].term == "Python"
    for change in (
        {"schema_version": "future"},
        {
            "requirements": [
                {"quote": "Python", "term": "Python", "priority": "essential", "verified": True}
            ]
        },
    ):
        with pytest.raises(ValidationError):
            ExtractionOutput.model_validate_json(json.dumps({**payload, **change}))
    with pytest.raises(ValidationError):
        parsed.requirements = ()


def test_unregistered_extraction_capability_cannot_call_provider() -> None:
    from actual.capabilities.probe import PROBE

    provider = FakeExtractionProvider()
    gateway = ModelGateway(provider, capabilities=(PROBE,))
    with pytest.raises(ModelFailure) as captured:
        asyncio.run(
            gateway.run(JOB_REQUIREMENTS, ExtractionInput(synthetic=True, job_text="Python"))
        )
    assert captured.value.code == FailureCode.UNSUPPORTED_CAPABILITY
    assert provider.requests == []
