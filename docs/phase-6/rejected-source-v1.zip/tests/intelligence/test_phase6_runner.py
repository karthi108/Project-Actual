"""The only external Job Intelligence entry point is a closed development run."""

import os
import subprocess
import sys
from pathlib import Path


def run(*arguments: str) -> subprocess.CompletedProcess[str]:
    environment = dict(os.environ)
    environment.pop("ACTUAL_MODEL_MODE", None)
    root = Path(__file__).resolve().parents[2]
    return subprocess.run(
        [sys.executable, str(root / "scripts/evaluate_phase6_live.py"), *arguments],
        cwd=root,
        env=environment,
        capture_output=True,
        text=True,
        timeout=15,
    )


def test_runner_rejects_arbitrary_prompt_or_file_before_provider_configuration() -> None:
    result = run("private-career-material.json")
    assert result.returncode == 2
    assert result.stdout.strip() == ('{"evaluation":"failed","error_code":"unsupported_arguments"}')
    assert result.stderr == ""


def test_runner_requires_explicit_synthetic_mode_without_stack_trace() -> None:
    result = run()
    assert result.returncode == 1
    assert result.stdout.strip() == ('{"error_code":"configuration","evaluation":"failed"}')
    assert result.stderr == ""
