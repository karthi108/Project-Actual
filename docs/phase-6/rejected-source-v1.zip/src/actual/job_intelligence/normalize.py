"""Small reviewed lexical mappings; uncertain meanings remain explicit proposals."""

import re
from typing import Any
from uuid import UUID, uuid5

from actual.career.assessments import (
    Priority,
    RequirementLike,
    UnresolvedReason,
    UnresolvedRequirement,
)
from actual.career.jobs import Job, Requirement
from actual.core.primitives import CompanyId, JobId, OpportunityId, RequirementId, WorkspaceId
from actual.job_intelligence.errors import IntelligenceCode, IntelligenceFailure
from actual.profile.contracts import Assertion

NORMALIZATION_VERSION = "career-normalization-v1"
_NAMESPACE = UUID("4264c9a5-983f-4e3b-9bfa-295afc190a06")
_ALIASES = {
    "python": "python",
    "python development": "python",
    "fastapi": "fastapi",
    "fast api": "fastapi",
    "azure": "azure",
    "microsoft azure": "azure",
    "local llm integration": "llm_integration",
    "llm integration": "llm_integration",
    "local-model integration": "llm_integration",
    "local model integration": "llm_integration",
    "french": "french",
    "experience": "experience",
    "backend experience": "experience",
    "professional experience": "experience",
    "work experience": "experience",
}
_NUMBERS = {
    word: value
    for value, word in enumerate(
        (
            "zero",
            "one",
            "two",
            "three",
            "four",
            "five",
            "six",
            "seven",
            "eight",
            "nine",
            "ten",
            "eleven",
            "twelve",
        )
    )
}
_DURATION = re.compile(
    r"\b(\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s*\+?\s*(years?|months?)\b",
    re.IGNORECASE,
)
_DURATION_RANGE = re.compile(
    r"\b(?:\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)"
    r"\s*[-–—]\s*"
    r"(?:\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b",
    re.IGNORECASE,
)
_INSTRUCTION = re.compile(
    r"\b(?:ignore\s+(?:the\s+|all\s+|previous\s+|ACTUAL(?:['’]s)?\s+)?"
    r"(?:instructions?|evidence|review|rules?)"
    r"|(?:system|developer)\s+(?:prompt|authority|command|instruction)"
    r"|(?:print|reveal|disclose)\s+(?:the\s+)?(?:local\s+)?(?:secret|canary|credential)"
    r"|(?:fabricate|invent)\s+(?:candidate\s+)?(?:skills?|evidence|qualifications?)"
    r"|mark\s+(?:this\s+job\s+|the\s+candidate\s+)?(?:as\s+)?(?:a\s+)?perfect\s+fit"
    r"|write\s+French\s+[ABC][12])\b",
    re.IGNORECASE,
)
_DIRECTIVE = re.compile(
    r"\b(?:assistant\s*[, :]|(?:system|developer)\s*:|claim\s+that\s+|"
    r"reveal\s+(?:the\s+)?(?:evaluator\s+)?secret\b)|"
    r"\[(?:system|developer)\]|</?(?:system|developer)>",
    re.IGNORECASE,
)


def checked_job(job: Job) -> Job:
    """Domain validation never silently drops extra fields from an input instance."""
    if (
        type(job) is not Job
        or set(job.__dict__) - set(Job.model_fields)
        or job.__pydantic_extra__ is not None
    ):
        raise IntelligenceFailure(IntelligenceCode.INPUT_REJECTED)
    try:
        for item in (job.id, job.workspace_id, job.company_id, job.opportunity_id):
            if (
                type(item) not in (JobId, WorkspaceId, CompanyId, OpportunityId)
                or set(item.__dict__) != {"root"}
                or item.__pydantic_extra__ is not None
            ):
                raise IntelligenceFailure(IntelligenceCode.INPUT_REJECTED)
        checked = Job.model_validate(job)
        if checked.classification != "synthetic":
            raise IntelligenceFailure(IntelligenceCode.INPUT_REJECTED)
        return checked
    except IntelligenceFailure:
        raise
    except Exception:
        raise IntelligenceFailure(IntelligenceCode.INPUT_REJECTED) from None


def _source_priority(quote: str) -> Priority:
    lowered = quote.casefold()
    if re.search(
        r"(?:not stated|not specified|unclear|ambiguous|whether .*mandatory|"
        r"not required|not mandatory)",
        lowered,
    ):
        return "ambiguous"
    essential = re.search(r"\b(?:essential|required|must|mandatory)\b", lowered) is not None
    preferred = (
        re.search(r"\b(?:preferred|optional|helpful|plus)\b|nice to have", lowered) is not None
    )
    if essential and preferred:
        raise IntelligenceFailure(IntelligenceCode.INVALID_REQUIREMENT)
    if essential:
        return "essential"
    if preferred:
        return "preferred"
    return "ambiguous"


def normalize_requirement(
    job: Job, *, quote: str, term: str, priority: Priority
) -> RequirementLike:
    checked = checked_job(job)
    if (
        type(quote) is not str
        or type(term) is not str
        or not 1 <= len(quote) <= 512
        or not 1 <= len(term) <= 64
        or term != term.strip()
        or term not in quote
        or checked.text.count(quote) != 1
        or priority not in ("essential", "preferred", "ambiguous")
    ):
        raise IntelligenceFailure(IntelligenceCode.INVALID_REQUIREMENT)
    start = checked.text.index(quote)
    # An extracted substring cannot discard a hostile directive surrounding it.
    # Check its containing sentence; other independent requirement sentences stay usable.
    before = list(re.finditer(r"[.!?](?:\s+|$)|\n", checked.text[:start]))
    context_start = before[-1].end() if before else 0
    after = re.search(r"[.!?](?:\s+|$)|\n", checked.text[start:])
    context_end = start + after.end() if after else len(checked.text)
    context = checked.text[context_start:context_end]
    if (
        _INSTRUCTION.search(context)
        or _DIRECTIVE.search(context)
        or _INSTRUCTION.search(quote)
        or _DIRECTIVE.search(quote)
    ):
        raise IntelligenceFailure(IntelligenceCode.UNSAFE_SOURCE)
    if priority != _source_priority(quote) or priority != _source_priority(context):
        raise IntelligenceFailure(IntelligenceCode.INVALID_REQUIREMENT)
    common: dict[str, Any] = {
        "id": RequirementId(
            "requirement_"
            + uuid5(
                _NAMESPACE,
                f"{checked.workspace_id.root}/{checked.id.root}/{checked.revision}/"
                f"{checked.content_digest}/{start}/{quote}/{term}",
            ).hex
        ),
        "workspace_id": checked.workspace_id,
        "revision": 1,
        "classification": "synthetic",
        "job_id": checked.id,
        "job_revision": checked.revision,
        "job_digest": checked.content_digest,
        "priority": priority,
        "source_start": start,
        "source_end": start + len(quote),
        "source_quote": quote,
        "origin": "ai_proposal",
        "review": None,
    }

    def unresolved(reason: UnresolvedReason) -> UnresolvedRequirement:
        return UnresolvedRequirement(**common, term=term, reason=reason)

    subject = _ALIASES.get(term.casefold())
    if subject is None:
        if re.search(r"\b(?:python|fastapi|azure)\s*(?:version\s*)?\d", term, re.IGNORECASE):
            return unresolved("unsupported_version_constraint")
        return unresolved(
            "ambiguous_alias" if term.casefold() in ("api", "cloud", "llm") else "unknown_term"
        )
    if re.search(r"\b(?:python|fastapi|azure)\s*(?:version\s*)?\d", context, re.IGNORECASE):
        return unresolved("unsupported_version_constraint")
    if subject == "french":
        levels = re.findall(r"\b([ABC][12])\b", context, re.IGNORECASE)
        if len(levels) != 1 or re.search(
            r"\b(?:below|above|under|over|less than|more than|at most)\b",
            context,
            re.IGNORECASE,
        ):
            return unresolved("unknown_language_level")
        number = {"A1": 1, "A2": 2, "B1": 3, "B2": 4, "C1": 5, "C2": 6}[levels[0].upper()]
        assertion = Assertion(kind="language", subject=subject, unit="cefr_level", value=number)
    elif subject == "experience":
        if re.search(
            r"\b(?:professional|production|commercial|leadership|managerial|"
            r"python|fastapi|azure|llm|french)\b",
            context,
            re.IGNORECASE,
        ):
            return unresolved("unsupported_experience_scope")
        matches = list(_DURATION.finditer(context))
        if (
            len(matches) != 1
            or _DURATION_RANGE.search(context)
            or re.search(
                r"\b(?:to|between|up to|at most|less than|more than)\b",
                context,
                re.IGNORECASE,
            )
        ):
            return unresolved("unknown_experience_duration")
        number_text, unit = matches[0].groups()
        count = int(number_text) if number_text.isdigit() else _NUMBERS[number_text.casefold()]
        number = count * (12 if unit.casefold().startswith("year") else 1)
        if not 1 <= number <= 600:
            raise IntelligenceFailure(IntelligenceCode.INVALID_REQUIREMENT)
        assertion = Assertion(kind="experience", subject=subject, unit="months", value=number)
    else:
        skill_levels = set(
            value.casefold()
            for value in re.findall(r"\b(introductory|working|strong)\b", context, re.IGNORECASE)
        )
        if len(skill_levels) != 1:
            return unresolved("unknown_skill_level")
        number = {"introductory": 1, "working": 2, "strong": 3}[skill_levels.pop()]
        assertion = Assertion(kind="skill", subject=subject, unit="skill_level", value=number)
    return Requirement(**common, assertion=assertion)
