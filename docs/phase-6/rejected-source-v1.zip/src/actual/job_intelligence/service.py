"""Synthetic read-only Job Intelligence; model output never changes profile facts."""

from dataclasses import dataclass, field

from pydantic import ValidationError

from actual.capabilities.job_requirements import JOB_REQUIREMENTS, ExtractionInput
from actual.career.assessments import JobFitAssessment
from actual.career.jobs import Job
from actual.models.contracts import InferenceMetadata
from actual.models.gateway import ModelGateway
from actual.profile.contracts import Profile

from .errors import IntelligenceFailure
from .matching import checked_profile, match_requirements
from .normalize import checked_job, normalize_requirement


@dataclass(frozen=True, kw_only=True)
class IntelligenceResult:
    assessment: JobFitAssessment = field(repr=False)
    metadata: InferenceMetadata


class JobIntelligence:
    """Narrow capability composition with no provider, persistence or HTTP dependency."""

    def __init__(self, gateway: ModelGateway) -> None:
        self._gateway = gateway

    async def assess(self, job: Job, profile: Profile) -> IntelligenceResult:
        if type(job) is not Job or type(profile) is not Profile:
            raise IntelligenceFailure("input_rejected")
        try:
            source = checked_job(job)
            candidate = checked_profile(profile)
            if (
                source.classification != "synthetic"
                or candidate.classification != "synthetic"
                or source.workspace_id != candidate.workspace_id
            ):
                raise IntelligenceFailure("input_rejected")
            request = ExtractionInput(synthetic=True, job_text=source.text)
        except (ValidationError, ValueError, TypeError, UnicodeError, RecursionError):
            raise IntelligenceFailure("input_rejected") from None

        proposal = await self._gateway.run(JOB_REQUIREMENTS, request)
        requirements = tuple(
            normalize_requirement(source, quote=unit.quote, term=unit.term, priority=unit.priority)
            for unit in proposal.value.requirements
        )
        assessment = match_requirements(source, candidate, requirements)
        return IntelligenceResult(assessment=assessment, metadata=proposal.metadata)
