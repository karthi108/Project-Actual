"""Atomic synthetic evaluation checkpoints; no model content or runtime intake."""

import json
import os
import re
from dataclasses import asdict, replace
from pathlib import Path

from actual.evaluation.job_intelligence import CasePrediction, Prediction
from actual.models.gateway import canonical_json

ATTEMPT_FIELDS = {
    "attempt_id",
    "trial",
    "case_id",
    "started_at",
    "finished_at",
    "duration_ms",
    "failure_code",
    "provider_metadata_available",
    "normalization_diagnostics",
    "gateway_schema_valid",
}
CONFIG_FIELDS = {
    "provider",
    "model",
    "timeout_seconds",
    "context_tokens",
    "max_output_tokens",
    "temperature",
    "seed",
}
FORBIDDEN_FIELDS = {
    "prompt",
    "prompts",
    "raw_prompt",
    "response",
    "responses",
    "raw_response",
    "job_text",
    "quote",
    "excerpt",
}


def _no_content(value: object) -> None:
    if isinstance(value, dict):
        if set(value) & FORBIDDEN_FIELDS:
            raise ValueError("Evaluation checkpoint rejects model content")
        for item in value.values():
            _no_content(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _no_content(item)


class TrialJournal:
    def __init__(
        self,
        *,
        path: Path,
        case_ids: tuple[str, ...],
        configuration: dict[str, object],
        frozen_sources: dict[str, str],
    ) -> None:
        if (
            not case_ids
            or len(set(case_ids)) != len(case_ids)
            or set(configuration) != CONFIG_FIELDS
        ):
            raise ValueError("Fixed evaluation case/configuration identities required")
        if (
            path.exists()
            or path.is_symlink()
            or path.parent.is_symlink()
            or path.parent.is_junction()
        ):
            raise ValueError("A new local checkpoint identity is required")
        self.path = path
        self.case_ids = case_ids
        self.configuration = dict(configuration)
        self.frozen_sources = dict(frozen_sources)
        self.records: list[tuple[int, CasePrediction]] = []
        self.attempts: list[dict[str, object]] = []
        self.status = "running"
        self.abort_code: str | None = None
        self._write()

    def _write(self) -> None:
        body = {
            "schema_version": "actual-phase6-evaluation-checkpoint-v1",
            "status": self.status,
            "abort_code": self.abort_code,
            "planned_trials": 3,
            "case_ids": self.case_ids,
            "requested_configuration": self.configuration,
            "frozen_sources_sha256": self.frozen_sources,
            "attempts": self.attempts,
            "records": [{"trial": trial, "prediction": asdict(row)} for trial, row in self.records],
        }
        _no_content(body)
        # Encode before touching the current valid checkpoint.
        payload = (canonical_json(body) + "\n").encode("utf-8")
        self.path.parent.mkdir(exist_ok=True)
        temporary = self.path.with_name(self.path.name + ".tmp")
        try:
            with temporary.open("wb") as output:
                output.write(payload)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)

    def record(self, *, trial: int, prediction: CasePrediction, attempt: dict[str, object]) -> None:
        expected_trial = len(self.records) // len(self.case_ids) + 1
        expected_case = self.case_ids[len(self.records) % len(self.case_ids)]
        if (
            self.status != "running"
            or expected_trial > 3
            or type(trial) is not int
            or trial != expected_trial
            or prediction.case_id != expected_case
            or set(attempt) - ATTEMPT_FIELDS
            or attempt.get("trial") != trial
            or attempt.get("case_id") != expected_case
        ):
            raise ValueError("Evaluation attempts must follow the declared case/trial order")
        # Revalidate metadata/derived values before checkpointing caller objects.
        checked = replace(
            prediction,
            predictions=tuple(Prediction(**asdict(item)) for item in prediction.predictions),
        )
        _no_content(asdict(checked))
        _no_content(attempt)
        json.dumps(attempt, allow_nan=False)
        self.records.append((trial, checked))
        self.attempts.append(dict(attempt))
        try:
            self._write()
        except Exception:
            self.records.pop()
            self.attempts.pop()
            raise

    def finalize(self, error_code: str | None = None) -> tuple[tuple[CasePrediction, ...], ...]:
        if error_code is not None and re.fullmatch(r"[a-z][a-z0-9_]{0,63}", error_code) is None:
            raise ValueError("A fixed safe abort code is required")
        completed = len(self.records) == 3 * len(self.case_ids)
        self.abort_code = error_code or (None if completed else "evaluation_incomplete")
        self.status = "complete" if completed and self.abort_code is None else "aborted"
        self._write()
        results = {(trial, row.case_id): row for trial, row in self.records}
        return tuple(
            tuple(
                results.get(
                    (trial, case_id), CasePrediction(case_id=case_id, failure_code="not_attempted")
                )
                for case_id in self.case_ids
            )
            for trial in (1, 2, 3)
        )
