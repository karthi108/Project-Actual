"""Three declared synthetic development trials, never arbitrary model intake.

No arguments. Run with ACTUAL_MODEL_MODE=synthetic-development. An owned
cloud-disabled Ollama child uses installed weights; raw model content is not
retained. Every inference attempt is reported, including failures. Evaluator
answers are loaded only after all runtime inference calls have finished.
"""

import asyncio
import hashlib
import json
import re
import shutil
import socket
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4, uuid5

import httpx2 as httpx
from phase6_journal import TrialJournal
from phase6_monitor import observe_network
from verify_phase5_live import server_environment

from actual.capabilities.job_requirements import JOB_REQUIREMENTS, ExtractionOutput
from actual.career.jobs import Job, Requirement
from actual.careerlab.validation import validate_input
from actual.careerlab_bridge import ImportContext, map_observable
from actual.core.primitives import ActorId, JobId, OpportunityId, WorkspaceId
from actual.evaluation.job_intelligence import (
    CasePrediction,
    GoldCase,
    Prediction,
    component_check,
    development_oracle_identity,
    evaluate_cases,
    evaluate_trial,
    evaluation_summary,
    load_adversarial_inputs,
    load_adversarial_oracles,
    load_development_ground_truth,
    load_development_oracles,
)
from actual.job_intelligence.development import load_development
from actual.job_intelligence.errors import IntelligenceFailure
from actual.job_intelligence.normalize import _source_priority, normalize_requirement
from actual.job_intelligence.service import JobIntelligence
from actual.models.config import OllamaSettings
from actual.models.contracts import (
    Capability,
    GenerationSettings,
    InferenceMetadata,
    InputT,
    OutputT,
    Proposal,
)
from actual.models.errors import ModelFailure
from actual.models.gateway import ModelGateway, canonical_json, metadata_json
from actual.models.ollama import OllamaQwenProvider
from actual.profile.contracts import Profile

ROOT = Path(__file__).resolve().parents[1]
TRIALS = 3
CONTEXT = ImportContext(
    workspace_id=WorkspaceId("workspace_" + "6" * 32),
    actor_id=ActorId("actor_" + "6" * 32),
)
NAMESPACE = UUID("a61b6113-bc8c-4f1d-a274-b451bfec99e0")


@dataclass(frozen=True)
class Case:
    case_id: str
    job: Job
    profile: Profile
    adversarial: bool = False


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen_sources() -> dict[str, str]:
    paths = [
        ROOT / "docs/phase-6/design.md",
        Path(__file__),
        ROOT / "scripts/verify_phase5_live.py",
        ROOT / "scripts/phase6_monitor.py",
        ROOT / "scripts/phase6_journal.py",
        ROOT / "pyproject.toml",
        ROOT / "uv.lock",
        *sorted((ROOT / "src/actual").rglob("*.py")),
        *sorted((ROOT / "datasets/manifests").glob("*.json")),
        *sorted((ROOT / "datasets/phase6").glob("*.json")),
    ]
    return {path.relative_to(ROOT).as_posix(): digest(path) for path in paths}


def cases() -> tuple[tuple[Case, ...], dict[str, str]]:
    values = load_development()
    ordinary = []
    for value in values:
        if value.id == "CAREER-DEV-008":
            if tuple(item.code for item in validate_input(value)) != ("application_transition",):
                raise RuntimeError("Negative fixture no longer has its accepted rejection")
            try:
                map_observable(value, CONTEXT)
            except ValueError:
                continue
            raise RuntimeError("Invalid fixture entered the runtime")
        world = map_observable(value, CONTEXT)
        seen = set()
        for job in world.jobs:
            if job.opportunity_id not in seen:
                ordinary.append(Case(value.id, job, world.profile))
                seen.add(job.opportunity_id)
    if len(ordinary) != 7:
        raise RuntimeError("Accepted valid development support changed")
    source = ROOT / "datasets/phase6/development-adversarial-inputs.json"
    records = load_adversarial_inputs()
    if len(records) != 4:
        raise RuntimeError("Four explicit synthetic adversarial cases are required")
    base = ordinary[0]
    attacks = []
    for row in records:
        job = base.job.model_copy(
            update={
                "id": JobId("job_" + uuid5(NAMESPACE, row.case_id).hex),
                "opportunity_id": OpportunityId("opportunity_" + uuid5(NAMESPACE, row.case_id).hex),
                "revision": 2,
                "text": row.text,
                "source_reference": "phase6:" + row.case_id,
            }
        )
        attacks.append(Case(row.case_id, job, base.profile, adversarial=True))
    return tuple(ordinary + attacks), {"adversarial_input_sha256": digest(source)}


class RecordingGateway(ModelGateway):
    """Evaluator instrumentation retains validated metadata only, never content."""

    last_metadata: InferenceMetadata | None = None
    current_job: Job | None = None
    diagnostics: list[dict[str, object]]

    async def run(
        self, capability: Capability[InputT, OutputT], request: InputT
    ) -> Proposal[OutputT]:
        self.last_metadata = None
        self.diagnostics = []
        result = await super().run(capability, request)
        self.last_metadata = result.metadata
        if self.current_job is not None and isinstance(result.value, ExtractionOutput):
            for index, unit in enumerate(result.value.requirements):
                try:
                    normalize_requirement(
                        self.current_job, quote=unit.quote, term=unit.term, priority=unit.priority
                    )
                except IntelligenceFailure as failure:
                    item: dict[str, object] = {
                        "unit_index": index,
                        "failure_code": failure.code.value,
                        "model_priority": unit.priority,
                        "source_occurrences": self.current_job.text.count(unit.quote),
                        "term_is_source_substring": unit.term in unit.quote,
                    }
                    if self.current_job.text.count(unit.quote) == 1:
                        start = self.current_job.text.index(unit.quote)
                        before = list(
                            re.finditer(r"[.!?](?:\s+|$)|\n", self.current_job.text[:start])
                        )
                        after = re.search(r"[.!?](?:\s+|$)|\n", self.current_job.text[start:])
                        context = self.current_job.text[
                            before[-1].end() if before else 0 : start + after.end()
                            if after
                            else len(self.current_job.text)
                        ]
                        try:
                            item["quote_priority"] = _source_priority(unit.quote)
                            item["context_priority"] = _source_priority(context)
                        except IntelligenceFailure:
                            item["priority_check"] = "conflicting_source_wording"
                    self.diagnostics.append(item)
        return result


async def predict(
    service: JobIntelligence,
    gateway: RecordingGateway,
    case: Case,
    trial: int,
    journal: TrialJournal,
) -> CasePrediction:
    before = case.profile.content_digest
    started = datetime.now(UTC)
    tick = time.monotonic()
    gateway.last_metadata = None
    gateway.current_job = case.job
    gateway.diagnostics = []
    metadata: tuple[dict[str, object], ...] = ()
    predictions: tuple[Prediction, ...] = ()
    failure_code = None
    cancelled = False
    try:
        result = await service.assess(case.job, case.profile)
        safe = json.loads(metadata_json(result.metadata))
        safe["identity"].pop("endpoint", None)
        metadata = (safe,)
        rows = []
        for row in result.assessment.rows:
            requirement = row.requirement
            assertion = requirement.assertion if isinstance(requirement, Requirement) else None
            rows.append(
                Prediction(
                    requirement_id=requirement.id.root,
                    opportunity_id=case.job.opportunity_id.root,
                    subject=assertion.subject if assertion else None,
                    kind=assertion.kind if assertion else None,
                    unit=assertion.unit if assertion else None,
                    minimum=assertion.value if assertion else None,
                    priority=requirement.priority,
                    status=row.status,
                    declared_shortfall=row.declared_shortfall,
                    claim_ids=tuple(ref.claim_id.root for ref in row.claim_refs),
                    evidence_ids=tuple(ref.evidence_id.root for ref in row.evidence_refs),
                )
            )
        predictions = tuple(rows)
    except (ModelFailure, IntelligenceFailure) as error:
        failure_code = error.code.value
        if gateway.last_metadata is not None:
            safe = json.loads(metadata_json(gateway.last_metadata))
            safe["identity"].pop("endpoint", None)
            metadata = (safe,)
    except asyncio.CancelledError:
        failure_code = "cancelled_by_supervision"
        cancelled = True
    attempt: dict[str, object] = {
        "attempt_id": uuid4().hex,
        "trial": trial,
        "case_id": case.case_id,
        "started_at": started.isoformat(),
        "finished_at": datetime.now(UTC).isoformat(),
        "duration_ms": (time.monotonic() - tick) * 1000,
        "failure_code": failure_code,
        "provider_metadata_available": bool(metadata),
        "gateway_schema_valid": gateway.last_metadata is not None,
        "normalization_diagnostics": gateway.diagnostics,
    }
    prediction = CasePrediction(
        case_id=case.case_id,
        predictions=predictions,
        failure_code=failure_code,
        metadata=metadata,
        known_claim_ids=tuple(item.id.root for item in case.profile.claims),
        known_evidence_ids=tuple(item.id.root for item in case.profile.evidence),
        profile_unchanged=before == case.profile.content_digest,
    )
    journal.record(trial=trial, prediction=prediction, attempt=attempt)
    print(
        canonical_json(
            {
                "case": case.case_id,
                "result": "failure" if failure_code else "success",
                "failure_code": failure_code,
            }
        ),
        flush=True,
    )
    if cancelled:
        raise asyncio.CancelledError
    return prediction


def gold_cases(selected: tuple[Case, ...]) -> tuple[GoldCase, ...]:
    """Evaluator boundary: called only AFTER all runtime model attempts."""
    ordinary = load_development_oracles(
        {
            case.case_id: {case.case_id + ":job:01": case.job.opportunity_id.root}
            for case in selected
            if not case.adversarial
        }
    )
    attacks = load_adversarial_oracles(
        {case.case_id: case.job.opportunity_id.root for case in selected if case.adversarial}
    )
    return ordinary + attacks


async def run_trials(
    local: OllamaSettings, selected: tuple[Case, ...], journal: TrialJournal
) -> None:
    gateway = RecordingGateway(OllamaQwenProvider(local), capabilities=(JOB_REQUIREMENTS,))
    service = JobIntelligence(gateway)
    for trial in range(1, TRIALS + 1):
        print(canonical_json({"trial": trial, "attempts": len(selected)}), flush=True)
        for case in selected:
            await predict(service, gateway, case, trial, journal)


def build_report(
    journal: TrialJournal,
    selected: tuple[Case, ...],
    fixture_hashes: dict[str, str],
    error_code: str | None,
) -> dict[str, object]:
    if frozen_sources() != journal.frozen_sources:
        error_code = "frozen_sources_changed"
    all_predictions = journal.finalize(error_code)
    gold = gold_cases(selected)
    component = component_check(load_development(), CONTEXT, load_development_ground_truth())
    correct, total = component["correct"], component["total"]
    if type(correct) is not int or type(total) is not int:
        raise RuntimeError("Invalid component evaluation counts")
    ordinary_ids = {case.case_id for case in selected if not case.adversarial}
    attack_ids = {case.case_id for case in selected if case.adversarial}
    trials = []
    for number, predictions in enumerate(all_predictions, 1):
        trials.append(
            evaluate_trial(
                trial=number,
                development=evaluate_cases(
                    tuple(case for case in gold if case.case_id in ordinary_ids),
                    tuple(item for item in predictions if item.case_id in ordinary_ids),
                ),
                adversarial=evaluate_cases(
                    tuple(case for case in gold if case.case_id in attack_ids),
                    tuple(item for item in predictions if item.case_id in attack_ids),
                ),
                component_correct=correct,
                component_total=total,
            )
        )
    identity = {
        "careerlab_manifest": json.loads(
            (ROOT / "datasets/manifests/careerlab-intelligence-env-v1.json").read_bytes()
        )["dataset_sha256"],
        "careerlab_input_hashes": {
            value.id: digest(ROOT / "datasets/development/inputs" / f"{value.id}.json")
            for value in load_development()
        },
        **fixture_hashes,
        "development_oracle_identity": development_oracle_identity(),
    }
    return {
        **evaluation_summary(tuple(trials), dataset_identity=identity),
        "scope": "CareerLab development performance; no held-out or real-world claim",
        "capability": JOB_REQUIREMENTS.identifier,
        "requested_configuration": {
            "provider": "ollama",
            **journal.configuration,
        },
        "frozen_sources_sha256": journal.frozen_sources,
        "fixture_sha256": fixture_hashes,
        "invalid_case_008": "rejected_before_inference",
        "distinct_posting_texts": 6,
        "valid_scenarios": 7,
        "gold_requirement_units_per_trial": 24,
        "deterministic_component": component,
        "attempts": journal.attempts,
        "attempted_calls": len(journal.attempts),
        "planned_calls": 33,
        "evaluation_abort_code": error_code,
        "verdict": "NO_GO"
        if error_code
        else evaluation_summary(tuple(trials), dataset_identity=identity)["verdict"],
        "accepted_base_commit": "09d765352eacfe61e6cb43c3ecc13c4338d26412",
    }


async def supervise(
    inference: asyncio.Task[None],
    observation: asyncio.Task[int],
    stopped: asyncio.Event,
) -> tuple[str | None, int | None]:
    """Stop new inference on inspection failure; retain checkpoints on cancellation."""
    abort_code = None
    samples = None
    try:
        done, _ = await asyncio.wait({observation, inference}, return_when=asyncio.FIRST_COMPLETED)
        if observation in done:
            await observation
            abort_code = "network_observation_ended_early"
        else:
            await inference
    except Exception:
        abort_code = (
            "network_inspection_failed" if observation.done() else "evaluation_pipeline_failed"
        )
    finally:
        if not inference.done():
            inference.cancel()
            await asyncio.gather(inference, return_exceptions=True)
        stopped.set()
        result = (await asyncio.gather(observation, return_exceptions=True))[0]
        if isinstance(result, int):
            samples = result
        else:
            abort_code = "network_inspection_failed"
    return abort_code, samples


async def verify() -> bool:
    settings = OllamaSettings.from_environment()
    # Phase-specific composition, preserving the accepted provider limits/defaults.
    settings = replace(
        settings,
        generation=GenerationSettings(
            timeout_seconds=120, context_tokens=4096, max_output_tokens=512
        ),
    )
    executable = shutil.which("ollama")
    if executable is None:
        raise RuntimeError("Installed Ollama is required")
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    local = replace(settings, base_url=f"http://127.0.0.1:{port}")
    selected, fixture_hashes = cases()
    run_id = uuid4().hex
    journal = TrialJournal(
        path=ROOT / f"evaluation-runs/phase6-{run_id}.checkpoint.json",
        case_ids=tuple(case.case_id for case in selected),
        configuration={"provider": "ollama", "model": local.model, **asdict(local.generation)},
        frozen_sources=frozen_sources(),
    )
    process = subprocess.Popen(
        [executable, "serve"],
        env=server_environment(port),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
    started_at = datetime.now(UTC).isoformat()
    try:
        async with asyncio.timeout(15):
            async with httpx.AsyncClient(
                trust_env=False, follow_redirects=False, timeout=1
            ) as client:
                while True:
                    if process.poll() is not None:
                        raise RuntimeError("Owned server exited before readiness")
                    try:
                        response = await client.get(local.base_url + "/api/status")
                        if (
                            response.status_code == 200
                            and response.json().get("cloud", {}).get("disabled") is True
                        ):
                            break
                    except (httpx.ConnectError, httpx.TimeoutException):
                        pass
                    await asyncio.sleep(0.2)
        inspected = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                f"Get-NetTCPConnection -State Listen -LocalPort {port} | "
                "Select-Object LocalAddress,OwningProcess | ConvertTo-Json -Compress",
            ],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        if inspected.returncode != 0 or json.loads(inspected.stdout) != {
            "LocalAddress": "127.0.0.1",
            "OwningProcess": process.pid,
        }:
            raise RuntimeError("Owned loopback process identity could not be verified")
        stopped = asyncio.Event()
        observation = asyncio.create_task(observe_network(process.pid, stopped))
        inference = asyncio.create_task(run_trials(local, selected, journal))
        abort_code, samples = await supervise(inference, observation, stopped)
        report = build_report(journal, selected, fixture_hashes, abort_code)
        report["run_id"] = run_id
        report["runner_version"] = "v2-checkpointed"
        report["environment"] = {
            "started_at": started_at,
            "finished_at": datetime.now(UTC).isoformat(),
            "cloud_disabled": True,
            "owned_loopback_process_verified": True,
            "tcp_observation_samples": samples,
            "network_inspection": "passed" if samples is not None else "failed",
            "non_loopback_tcp_connections_observed": 0 if samples is not None else None,
            "model_downloads": 0,
            "application_state_writes": 0,
        }
        destination = ROOT / f"evaluation-runs/phase6-{run_id}.report.json"
        destination.parent.mkdir(exist_ok=True)
        destination.write_text(canonical_json(report) + "\n", encoding="utf-8", newline="\n")
        print(
            canonical_json(
                {
                    "evaluation": "recorded",
                    "verdict": report["verdict"],
                    "trials": TRIALS,
                    "attempts": report["attempted_calls"],
                    "report": destination.relative_to(ROOT).as_posix(),
                }
            ),
            flush=True,
        )
        return report["verdict"] == "GO"
    finally:
        # The live Popen handle identifies this exact owned server. Kill its tree
        # while it is still alive so timed-out runner children do not become orphans.
        if process.poll() is None:
            killed = subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                capture_output=True,
                timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            if killed.returncode != 0 and process.poll() is None:
                process.kill()
                process.wait(timeout=5)
                raise RuntimeError("Owned server tree cleanup could not be confirmed")
        process.wait(timeout=5)


if __name__ == "__main__":
    if len(sys.argv) != 1:
        print('{"evaluation":"failed","error_code":"unsupported_arguments"}')
        raise SystemExit(2)
    try:
        if not asyncio.run(verify()):
            raise SystemExit(1)
    except (ModelFailure, IntelligenceFailure) as failure:
        print(canonical_json({"evaluation": "failed", "error_code": failure.code.value}))
        raise SystemExit(1) from None
    except (
        RuntimeError,
        TimeoutError,
        OSError,
        ValueError,
        subprocess.TimeoutExpired,
        httpx.HTTPError,
    ):
        print('{"evaluation":"failed","error_code":"verification_environment"}')
        raise SystemExit(1) from None
